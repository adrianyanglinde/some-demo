export const SET_FILTER = 'SET_FILTER';
