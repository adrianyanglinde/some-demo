import { SET_FILTER } from './actionTypes';

export const setFilter = (filter) => ({
    type: SET_FILTER,
    payload: {
        filter: filter
    }
});
