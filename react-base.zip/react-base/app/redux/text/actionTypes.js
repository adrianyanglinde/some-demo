export const SET_TEXT = 'SET_TEXT';
